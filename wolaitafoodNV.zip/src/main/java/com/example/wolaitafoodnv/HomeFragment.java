package com.example.wolaitafoodnv;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Spinner;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import android.widget.ListView;
import androidx.appcompat.widget.SearchView;
import java.util.ArrayList;
import java.util.List;

public class HomeFragment extends Fragment {

    private ListView lvFoodItems;
    private SearchView searchView;
    private Spinner spinnerFilter;
    private DatabaseHelper databaseHelper;
    private FoodAdapter foodAdapter;
    private List<Food> foodList;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_home, container, false);

        lvFoodItems = view.findViewById(R.id.lvFoodItems);
        searchView = view.findViewById(R.id.searchView);
        spinnerFilter = view.findViewById(R.id.spinnerFilter);
        databaseHelper = new DatabaseHelper(getContext());
        foodList = new ArrayList<>();
        foodAdapter = new FoodAdapter(getContext(), foodList);

        lvFoodItems.setAdapter(foodAdapter);

        loadFoodItems();

        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(getContext(),
                R.array.filter_options, android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerFilter.setAdapter(adapter);

        spinnerFilter.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                String filter = parent.getItemAtPosition(position).toString();
                filterFoodsByCategory(filter);
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
            }
        });

        searchView.setIconifiedByDefault(false);

        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) {
                return false;
            }

            @Override
            public boolean onQueryTextChange(String newText) {
                filterFoods(newText);
                return true;
            }
        });

        return view;
    }

    private void loadFoodItems() {
        foodList.clear();
        foodList.addAll(databaseHelper.getAllFoodItems());
        foodAdapter.notifyDataSetChanged();
    }

    private void filterFoods(String query) {
        List<Food> filteredFoodList = new ArrayList<>();
        for (Food food : foodList) {
            if (food.getFoodName().toLowerCase().contains(query.toLowerCase())) {
                filteredFoodList.add(food);
            }
        }
        foodAdapter.updateList(filteredFoodList);
    }

    private void filterFoodsByCategory(String category) {
        if (category.equals("All")) {
            loadFoodItems();
        } else {
            List<Food> filteredFoodList = new ArrayList<>();
            for (Food food : foodList) {
                if (food.getCategory().equals(category)) {
                    filteredFoodList.add(food);
                }
            }
            foodAdapter.updateList(filteredFoodList);
        }
    }
}
