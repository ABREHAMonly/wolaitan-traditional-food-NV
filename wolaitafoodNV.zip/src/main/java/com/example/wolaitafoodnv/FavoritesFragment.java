package com.example.wolaitafoodnv;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ListView;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import java.util.List;

public class FavoritesFragment extends Fragment {

    private ListView listViewFavorites;
    private FoodAdapter foodAdapter; // Assuming you have a FoodAdapter
    private DatabaseHelper databaseHelper;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_favorites, container, false);

        listViewFavorites = view.findViewById(R.id.listViewFavorites); // Make sure to add this in your XML
        databaseHelper = new DatabaseHelper(getContext());

        loadFavoriteFoods(); // Load favorite foods from the database

        return view;
    }

    private void loadFavoriteFoods() {
        List<Food> favoriteFoods = databaseHelper.getAllFavoriteFoods(); // Fetch favorite foods
        foodAdapter = new FoodAdapter(getContext(), favoriteFoods); // Initialize adapter
        listViewFavorites.setAdapter(foodAdapter); // Set adapter to ListView
    }
}