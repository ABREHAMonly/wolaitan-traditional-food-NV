package com.example.wolaitafoodnv;

public class Food {
    private String foodName;          // Name of the food item
    private String description;        // Description of the food item
    private String nutritionalValues;  // Nutritional values of the food item
    private String healthBenefits;     // Health benefits of the food item
    private String image;              // Image URL or path of the food item
    private String category;           // Category of the food item
    private boolean isFavorite;        // Favorite status

    // Constructor
    public Food(String foodName, String description, String nutritionalValues,
                String healthBenefits, String image, String category) {
        this.foodName = foodName;
        this.description = description;
        this.nutritionalValues = nutritionalValues;
        this.healthBenefits = healthBenefits;
        this.image = image;
        this.category = category;
        this.isFavorite = false;  // Default to not favorite
    }

    // Getters and Setters
    public String getFoodName() {
        return foodName;
    }

    public void setFoodName(String foodName) {
        this.foodName = foodName;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getNutritionalValues() {
        return nutritionalValues;
    }

    public void setNutritionalValues(String nutritionalValues) {
        this.nutritionalValues = nutritionalValues;
    }

    public String getHealthBenefits() {
        return healthBenefits;
    }

    public void setHealthBenefits(String healthBenefits) {
        this.healthBenefits = healthBenefits;
    }

    public String getImage() {
        return image;
    }

    public void setImage(String image) {
        this.image = image;
    }

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    public boolean isFavorite() {
        return isFavorite;
    }

    public void setFavorite(boolean favorite) {
        this.isFavorite = favorite;
    }

    // Optional: Method to return a summary of the food item
    public String getSummary() {
        return foodName + ": " + description +
                " [Nutritional Values: " + nutritionalValues +
                ", Health Benefits: " + healthBenefits + "]";
    }
}