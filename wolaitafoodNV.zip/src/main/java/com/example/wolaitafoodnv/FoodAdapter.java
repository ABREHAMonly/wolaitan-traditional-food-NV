package com.example.wolaitafoodnv;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.bumptech.glide.Glide;

import java.util.List;

public class FoodAdapter extends BaseAdapter {

    private Context context;
    private List<Food> foodList;
    private DatabaseHelper databaseHelper;

    public FoodAdapter(Context context, List<Food> foodList) {
        this.context = context;
        this.foodList = foodList;
        this.databaseHelper = new DatabaseHelper(context);
    }

    @Override
    public int getCount() {
        return foodList.size();
    }

    @Override
    public Object getItem(int position) {
        return foodList.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        ViewHolder holder;

        if (convertView == null) {
            convertView = LayoutInflater.from(context).inflate(R.layout.item_food, parent, false);
            holder = new ViewHolder();
            holder.ivFoodImage = convertView.findViewById(R.id.ivFoodImage);
            holder.tvFoodName = convertView.findViewById(R.id.tvFoodName);
            holder.tvDescription = convertView.findViewById(R.id.tvDescription);
            holder.tvNutritionalValues = convertView.findViewById(R.id.tvNutritionalValues);
            holder.tvHealthBenefits = convertView.findViewById(R.id.tvHealthBenefits);
            holder.ivFavoriteIcon = convertView.findViewById(R.id.ivFavoriteIcon); // Favorite icon
            convertView.setTag(holder);
        } else {
            holder = (ViewHolder) convertView.getTag();
        }

        Food food = foodList.get(position);
        holder.tvFoodName.setText(food.getFoodName());
        holder.tvDescription.setText(food.getDescription());
        holder.tvNutritionalValues.setText(food.getNutritionalValues());
        holder.tvHealthBenefits.setText(food.getHealthBenefits());

        // Load the image using Glide
        loadImage(holder.ivFoodImage, food.getImage());

        // Set the favorite icon based on favorite status
        holder.ivFavoriteIcon.setImageResource(food.isFavorite() ? R.drawable.ic_favorite : R.drawable.ic_favorite_border);

        // Set click listener for favorite icon
        holder.ivFavoriteIcon.setOnClickListener(v -> {
            boolean isFavorite = !food.isFavorite(); // Toggle favorite status
            food.setFavorite(isFavorite);
            databaseHelper.updateFoodFavoriteStatus(food.getFoodName(), isFavorite);
            notifyDataSetChanged(); // Refresh the list
            Toast.makeText(context, isFavorite ? "Added to favorites" : "Removed from favorites", Toast.LENGTH_SHORT).show();
        });

        return convertView;
    }

    private void loadImage(ImageView imageView, String imagePath) {
        if (imagePath != null && !imagePath.isEmpty()) {
            Glide.with(context)
                    .load(imagePath)
                    .placeholder(R.drawable.ic_placeholder) // Placeholder while loading
                    .error(R.drawable.ic_error) // Error image if loading fails
                    .into(imageView);
        } else {
            imageView.setImageResource(R.drawable.ic_placeholder); // Fallback image if path is empty
        }
    }

    public void updateList(List<Food> newList) {
        foodList.clear();
        foodList.addAll(newList);
        notifyDataSetChanged();
    }

    static class ViewHolder {
        ImageView ivFoodImage;
        TextView tvFoodName;
        TextView tvDescription;
        TextView tvNutritionalValues;
        TextView tvHealthBenefits;
        ImageView ivFavoriteIcon; // Updated to ImageView for the favorite icon
    }
}