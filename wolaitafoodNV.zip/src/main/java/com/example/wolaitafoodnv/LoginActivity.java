package com.example.wolaitafoodnv;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class LoginActivity extends AppCompatActivity {

    private EditText etEmail, etPassword;
    private Button btnLogin;
    private TextView tvRegister, tvForgotPassword;

    private DatabaseHelper databaseHelper;

    // Admin credentials
    private static final String ADMIN_EMAIL = "Abrehamonly@gmail.com";
    private static final String ADMIN_PASSWORD = "12345678";

    private static final String TAG = "LoginActivity";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        // Initialize UI components
        etEmail = findViewById(R.id.etEmail);
        etPassword = findViewById(R.id.etPassword);
        btnLogin = findViewById(R.id.btnLogin);
        tvRegister = findViewById(R.id.tvRegister);
        tvForgotPassword = findViewById(R.id.tvForgotPassword);

        // Initialize DatabaseHelper
        databaseHelper = new DatabaseHelper(this);

        // Set up login button click listener
        btnLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                handleLogin();
            }
        });

        // Set up register button click listener
        tvRegister.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(LoginActivity.this, RegisterActivity.class));
            }
        });

        // Set up forgot password button click listener
        tvForgotPassword.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(LoginActivity.this, ForgotPasswordActivity.class));
            }
        });
    }

    private void handleLogin() {
        String email = etEmail.getText().toString().trim();
        String password = etPassword.getText().toString().trim();

        // Validate input fields
        if (TextUtils.isEmpty(email)) {
            showToast("Please enter your email");
        } else if (TextUtils.isEmpty(password)) {
            showToast("Please enter your password");
        } else {
            loginUser(email, password);
        }
    }

    private void loginUser(String email, String password) {
        try {
            Log.d(TAG, "Attempting to log in with email: " + email);

            // Check for admin login
            if (email.equals(ADMIN_EMAIL) && password.equals(ADMIN_PASSWORD)) {
                Log.d(TAG, "Admin login successful");
                Intent intent = new Intent(LoginActivity.this, AdminActivity.class);
                startActivity(intent);
                finish();
            } else {
                // Validate against stored user data in SQLite database
                if (databaseHelper.checkUser(email, password)) {
                    Log.d(TAG, "User login successful");
                    onLoginSuccess(email);  // Call onLoginSuccess with email
                } else {
                    Log.e(TAG, "Invalid email or password for user: " + email);
                    showToast("Invalid email or password");
                }
            }
        } catch (Exception e) {
            Log.e(TAG, "Error during login", e);
            showToast("An error occurred during login");
        }
    }

    private void onLoginSuccess(String username) {
        loadUserData(username); // Call this after successful login
        Intent intent = new Intent(LoginActivity.this, HomeActivity.class);
        intent.putExtra("USERNAME", username); // Pass the username to the next activity
        startActivity(intent);
        finish();
    }

    private void loadUserData(String username) {
        // Implementation of loading user data goes here
        Log.d(TAG, "Loading user data for: " + username);
        // Example: You can call databaseHelper.getUser(username) here
    }

    private void showToast(String message) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show();
    }
}