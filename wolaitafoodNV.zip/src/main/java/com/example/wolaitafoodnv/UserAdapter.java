package com.example.wolaitafoodnv;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import java.util.List;

public class UserAdapter extends RecyclerView.Adapter<UserAdapter.UserViewHolder> {

    private Context context;
    private List<String> users;

    public UserAdapter(Context context, List<String> users) {
        this.context = context;
        this.users = users;
    }

    @NonNull
    @Override
    public UserViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.item_user, parent, false);
        return new UserViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull UserViewHolder holder, int position) {
        String email = users.get(position);
        holder.tvEmail.setText(email);

        holder.btnDeleteUser.setOnClickListener(v -> {
            // Delete user logic here
            users.remove(position);
            notifyItemRemoved(position);
            notifyItemRangeChanged(position, users.size());
            Toast.makeText(context, "User deleted: " + email, Toast.LENGTH_SHORT).show();

            // Optional: Call to database helper to delete the user from the database (not shown in this example)
        });
    }

    @Override
    public int getItemCount() {
        return users.size();
    }

    static class UserViewHolder extends RecyclerView.ViewHolder {
        TextView tvEmail;
        Button btnDeleteUser;

        public UserViewHolder(@NonNull View itemView) {
            super(itemView);
            tvEmail = itemView.findViewById(R.id.tvEmail);
            btnDeleteUser = itemView.findViewById(R.id.btnDeleteUser);
        }
    }
}