package com.example.wolaitafoodnv;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

import java.util.ArrayList;
import java.util.List;

public class DatabaseHelper extends SQLiteOpenHelper {
    private static final String DATABASE_NAME = "users.db";
    private static final int DATABASE_VERSION = 1;

    // User Table
    private static final String TABLE_USERS = "users";
    private static final String COLUMN_ID = "id";
    private static final String COLUMN_EMAIL = "email";
    private static final String COLUMN_PASSWORD = "password";

    // Food Table
    private static final String TABLE_FOOD = "food";
    private static final String COLUMN_FOOD_ID = "food_id";
    private static final String COLUMN_FOOD_NAME = "food_name";
    private static final String COLUMN_DESCRIPTION = "description";
    private static final String COLUMN_NUTRITIONAL_VALUES = "nutritional_values";
    private static final String COLUMN_HEALTH_BENEFITS = "health_benefits";
    private static final String COLUMN_IMAGE = "image";
    private static final String COLUMN_IS_FAVORITE = "is_favorite";
    private static final String COLUMN_CATEGORY = "category";

    private static final String TAG = "DatabaseHelper";

    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        try {
            // Create Users Table
            db.execSQL("CREATE TABLE " + TABLE_USERS + " ("
                    + COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, "
                    + COLUMN_EMAIL + " TEXT UNIQUE NOT NULL, "
                    + COLUMN_PASSWORD + " TEXT NOT NULL)");

            // Create Food Table
            db.execSQL("CREATE TABLE " + TABLE_FOOD + " ("
                    + COLUMN_FOOD_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, "
                    + COLUMN_FOOD_NAME + " TEXT NOT NULL, "
                    + COLUMN_DESCRIPTION + " TEXT, "
                    + COLUMN_NUTRITIONAL_VALUES + " TEXT, "
                    + COLUMN_HEALTH_BENEFITS + " TEXT, "
                    + COLUMN_IMAGE + " TEXT, "
                    + COLUMN_IS_FAVORITE + " INTEGER DEFAULT 0, "
                    + COLUMN_CATEGORY + " TEXT)");

            Log.d(TAG, "Database created with tables: " + TABLE_USERS + ", " + TABLE_FOOD);
            addTestUser(db);
        } catch (SQLException e) {
            Log.e(TAG, "Error creating database: " + e.getMessage());
        }
    }

    private void addTestUser(SQLiteDatabase db) {
        ContentValues values = new ContentValues();
        values.put(COLUMN_EMAIL, "testuser@gmail.com");
        values.put(COLUMN_PASSWORD, "password123");
        db.insert(TABLE_USERS, null, values);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        try {
            db.execSQL("DROP TABLE IF EXISTS " + TABLE_USERS);
            db.execSQL("DROP TABLE IF EXISTS " + TABLE_FOOD);
            onCreate(db);
            Log.d(TAG, "Database upgraded to version: " + newVersion);
        } catch (SQLException e) {
            Log.e(TAG, "Error upgrading database: " + e.getMessage());
        }
    }

    public List<Food> getAllFoodItems() {
        return fetchFoodItems(null, null);
    }

    public List<Food> getAllFavoriteFoods() {
        return fetchFoodItems(COLUMN_IS_FAVORITE + " = ?", new String[]{"1"});
    }

    private List<Food> fetchFoodItems(String selection, String[] selectionArgs) {
        List<Food> foodItems = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = null;

        try {
            cursor = db.query(TABLE_FOOD, null, selection, selectionArgs, null, null, null);
            if (cursor != null && cursor.moveToFirst()) {
                do {
                    Food food = new Food(
                            cursor.getString(cursor.getColumnIndex(COLUMN_FOOD_NAME)),
                            cursor.getString(cursor.getColumnIndex(COLUMN_DESCRIPTION)),
                            cursor.getString(cursor.getColumnIndex(COLUMN_NUTRITIONAL_VALUES)),
                            cursor.getString(cursor.getColumnIndex(COLUMN_HEALTH_BENEFITS)),
                            cursor.getString(cursor.getColumnIndex(COLUMN_IMAGE)),
                            cursor.getString(cursor.getColumnIndex(COLUMN_CATEGORY))
                    );
                    food.setFavorite(cursor.getInt(cursor.getColumnIndex(COLUMN_IS_FAVORITE)) == 1);
                    foodItems.add(food);
                } while (cursor.moveToNext());
            }
        } catch (SQLException e) {
            Log.e(TAG, "Error fetching food items: " + e.getMessage());
        } finally {
            if (cursor != null) cursor.close();
            db.close();
        }

        return foodItems;
    }

    public boolean updateFoodFavoriteStatus(String foodName, boolean isFavorite) {
        ContentValues values = new ContentValues();
        values.put(COLUMN_IS_FAVORITE, isFavorite ? 1 : 0);
        return updateFoodStatus(values, foodName);
    }

    public List<String> getAllUsers() {
        List<String> users = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = null;

        try {
            cursor = db.rawQuery("SELECT * FROM " + TABLE_USERS, null);
            if (cursor != null && cursor.moveToFirst()) {
                do {
                    users.add(cursor.getString(cursor.getColumnIndex(COLUMN_EMAIL)));
                } while (cursor.moveToNext());
            }
        } catch (SQLException e) {
            Log.e(TAG, "Error fetching users: " + e.getMessage());
        } finally {
            if (cursor != null) cursor.close();
            db.close();
        }

        return users;
    }

    public boolean updateUserPassword(String email, String newPassword) {
        ContentValues values = new ContentValues();
        values.put(COLUMN_PASSWORD, newPassword);
        return updateUser(values, email);
    }

    public boolean checkUser(String email, String password) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = null;
        boolean userExists = false;

        try {
            cursor = db.query(TABLE_USERS, new String[]{COLUMN_ID},
                    COLUMN_EMAIL + "=? AND " + COLUMN_PASSWORD + "=?",
                    new String[]{email, password}, null, null, null);

            userExists = cursor != null && cursor.getCount() > 0;
            Log.d(TAG, userExists ? "User found: " + email : "User not found: " + email);
        } catch (SQLException e) {
            Log.e(TAG, "Error checking user: " + e.getMessage());
        } finally {
            if (cursor != null) cursor.close();
            db.close();
        }

        return userExists;
    }

    public boolean registerUser(String email, String password) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_EMAIL, email);
        values.put(COLUMN_PASSWORD, password);

        long result = db.insert(TABLE_USERS, null, values);
        db.close();
        return result != -1;
    }

    public List<String> getAllCategories() {
        List<String> categories = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = null;

        try {
            cursor = db.rawQuery("SELECT DISTINCT " + COLUMN_CATEGORY + " FROM " + TABLE_FOOD, null);
            if (cursor != null && cursor.moveToFirst()) {
                do {
                    categories.add(cursor.getString(cursor.getColumnIndex(COLUMN_CATEGORY)));
                } while (cursor.moveToNext());
            }
        } catch (SQLException e) {
            Log.e(TAG, "Error fetching categories: " + e.getMessage());
        } finally {
            if (cursor != null) cursor.close();
            db.close();
        }

        return categories;
    }

    public boolean updateFood(String foodName, String description, String nutritionalValues,
                              String healthBenefits, String image, String category) {
        ContentValues values = new ContentValues();
        values.put(COLUMN_DESCRIPTION, description);
        values.put(COLUMN_NUTRITIONAL_VALUES, nutritionalValues);
        values.put(COLUMN_HEALTH_BENEFITS, healthBenefits);
        values.put(COLUMN_IMAGE, image);
        values.put(COLUMN_CATEGORY, category);

        return updateFoodStatus(values, foodName);
    }

    public boolean insertFood(String foodName, String description, String nutritionalValues,
                              String healthBenefits, String imagePath, String category) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_FOOD_NAME, foodName);
        values.put(COLUMN_DESCRIPTION, description);
        values.put(COLUMN_NUTRITIONAL_VALUES, nutritionalValues);
        values.put(COLUMN_HEALTH_BENEFITS, healthBenefits);
        values.put(COLUMN_IMAGE, imagePath);
        values.put(COLUMN_CATEGORY, category);

        long result = db.insert(TABLE_FOOD, null, values);
        db.close();
        return result != -1;
    }

    public boolean deleteFood(String foodName) {
        SQLiteDatabase db = this.getWritableDatabase();
        int rowsAffected = db.delete(TABLE_FOOD, COLUMN_FOOD_NAME + "=?", new String[]{foodName});
        db.close();
        return rowsAffected > 0;
    }

    private boolean updateFoodStatus(ContentValues values, String foodName) {
        SQLiteDatabase db = this.getWritableDatabase();
        int rowsAffected = db.update(TABLE_FOOD, values, COLUMN_FOOD_NAME + "=?", new String[]{foodName});
        db.close();
        return rowsAffected > 0;
    }

    private boolean updateUser(ContentValues values, String email) {
        SQLiteDatabase db = this.getWritableDatabase();
        int rowsAffected = db.update(TABLE_USERS, values, COLUMN_EMAIL + "=?", new String[]{email});
        db.close();
        return rowsAffected > 0;
    }
}