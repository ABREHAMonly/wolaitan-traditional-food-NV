package com.example.wolaitafoodnv;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.text.TextUtils;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.Toast;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class AdminActivity extends AppCompatActivity {

    private static final int PICK_IMAGE_REQUEST = 1;

    private EditText etFoodName, etDescription, etNutritionalValues, etHealthBenefits;
    private Spinner spinnerCategory;
    private ImageView ivFoodImage;
    private Button btnAddFood, btnUpdateFood, btnDeleteFood, btnLogout, btnUploadImage;
    private RecyclerView rvUsers;
    private DatabaseHelper databaseHelper;
    private List<String> usersList;
    private UserAdapter userAdapter;
    private String selectedImagePath;
    private String selectedCategory;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin);

        // Initialize UI elements
        initViews();

        // Setup database helper and user adapter
        databaseHelper = new DatabaseHelper(this);
        usersList = new ArrayList<>();
        userAdapter = new UserAdapter(this, usersList);

        // Setup RecyclerView
        rvUsers.setLayoutManager(new LinearLayoutManager(this));
        rvUsers.setAdapter(userAdapter);

        // Load registered users and setup category spinner
        loadRegisteredUsers();
        setupCategorySpinner();

        // Setup button click listeners
        setupButtonListeners();

        // Load food items for viewing
        loadFoodItems();
    }

    private void initViews() {
        etFoodName = findViewById(R.id.etFoodName);
        etDescription = findViewById(R.id.etDescription);
        etNutritionalValues = findViewById(R.id.etNutritionalValues);
        etHealthBenefits = findViewById(R.id.etHealthBenefits);
        spinnerCategory = findViewById(R.id.spinnerCategory);
        ivFoodImage = findViewById(R.id.ivFoodImage);
        btnUploadImage = findViewById(R.id.btnUploadImage);
        btnAddFood = findViewById(R.id.btnAddFood);
        btnUpdateFood = findViewById(R.id.btnUpdateFood);
        btnDeleteFood = findViewById(R.id.btnDeleteFood);
        btnLogout = findViewById(R.id.btnLogout);
        rvUsers = findViewById(R.id.rvUsers);
    }

    private void setupButtonListeners() {
        btnUploadImage.setOnClickListener(v -> openImageChooser());
        btnAddFood.setOnClickListener(v -> addFood());
        btnUpdateFood.setOnClickListener(v -> updateFood());
        btnDeleteFood.setOnClickListener(v -> deleteFood());
        btnLogout.setOnClickListener(v -> logout());
    }

    private void loadRegisteredUsers() {
        usersList.clear();
        usersList.addAll(databaseHelper.getAllUsers());
        userAdapter.notifyDataSetChanged();
    }

    private void setupCategorySpinner() {
        List<String> categories = Arrays.asList(getResources().getStringArray(R.array.filter_options));
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, categories);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerCategory.setAdapter(adapter);

        spinnerCategory.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                selectedCategory = parent.getItemAtPosition(position).toString();
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
                selectedCategory = null;
            }
        });
    }

    private void openImageChooser() {
        Intent intent = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
        startActivityForResult(intent, PICK_IMAGE_REQUEST);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == PICK_IMAGE_REQUEST && resultCode == RESULT_OK && data != null && data.getData() != null) {
            Uri imageUri = data.getData();
            ivFoodImage.setImageURI(imageUri);
            selectedImagePath = imageUri.toString();
        }
    }

    private void addFood() {
        if (validateFields()) {
            boolean isInserted = databaseHelper.insertFood(
                    etFoodName.getText().toString().trim(),
                    etDescription.getText().toString().trim(),
                    etNutritionalValues.getText().toString().trim(),
                    etHealthBenefits.getText().toString().trim(),
                    selectedImagePath,
                    selectedCategory
            );

            showToast(isInserted ? "Food added" : "Failed to add food");
            if (isInserted) {
                clearFields();
                loadFoodItems(); // Reload food items
            }
        }
    }

    private void updateFood() {
        if (validateFields()) {
            boolean isUpdated = databaseHelper.updateFood(
                    etFoodName.getText().toString().trim(),
                    etDescription.getText().toString().trim(),
                    etNutritionalValues.getText().toString().trim(),
                    etHealthBenefits.getText().toString().trim(),
                    selectedImagePath,
                    selectedCategory
            );

            showToast(isUpdated ? "Food updated" : "Failed to update food");
            if (isUpdated) {
                clearFields();
                loadFoodItems(); // Reload food items
            }
        }
    }

    private void deleteFood() {
        String foodName = etFoodName.getText().toString().trim();
        if (!foodName.isEmpty()) {
            boolean isDeleted = databaseHelper.deleteFood(foodName);
            showToast(isDeleted ? "Food deleted" : "Failed to delete food");
            if (isDeleted) {
                clearFields(); // Clear fields after deletion
                loadFoodItems(); // Reload food items
            }
        } else {
            showToast("Please enter the food name");
        }
    }

    private boolean validateFields() {
        if (TextUtils.isEmpty(etFoodName.getText()) ||
                TextUtils.isEmpty(etDescription.getText()) ||
                TextUtils.isEmpty(etNutritionalValues.getText()) ||
                TextUtils.isEmpty(etHealthBenefits.getText()) ||
                selectedCategory == null ||
                selectedImagePath == null) {
            showToast("Please fill all fields");
            return false;
        }
        return true;
    }

    private void clearFields() {
        etFoodName.setText("");
        etDescription.setText("");
        etNutritionalValues.setText("");
        etHealthBenefits.setText("");
        ivFoodImage.setImageResource(R.drawable.ic_placeholder); // Reset image
        spinnerCategory.setSelection(0); // Reset spinner
        selectedImagePath = null; // Reset image path
    }

    private void logout() {
        Intent intent = new Intent(AdminActivity.this, LoginActivity.class);
        startActivity(intent);
        finish();
    }

    private void loadFoodItems() {
        // Implement logic to load food items into the UI (e.g., a RecyclerView)
        // This can be similar to how users are loaded
    }

    private void showToast(String message) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show();
    }
}